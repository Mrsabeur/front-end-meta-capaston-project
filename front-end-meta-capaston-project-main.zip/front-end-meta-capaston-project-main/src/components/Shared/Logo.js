import { ReactComponent as MyIcon } from "../../assets/images/Logo.svg";

const Logo = () => {
  return (
    <>
      <MyIcon />
    </>
  );
};
export default Logo;

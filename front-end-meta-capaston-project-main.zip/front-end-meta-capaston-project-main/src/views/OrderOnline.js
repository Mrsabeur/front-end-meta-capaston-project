const OrderOnline = () => {
  return (
    <>
      <p>OrderOnline</p>
    </>
  );
};

export default OrderOnline;

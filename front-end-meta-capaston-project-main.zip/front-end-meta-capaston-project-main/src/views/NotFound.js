const NotFound = () => {
  return (
    <>
      <p>Opps Not Found Page 404</p>
    </>
  );
};

export default NotFound;

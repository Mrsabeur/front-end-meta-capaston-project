const Home = () => {
  return (
    <>
      <p>Home</p>
    </>
  );
};

export default Home;

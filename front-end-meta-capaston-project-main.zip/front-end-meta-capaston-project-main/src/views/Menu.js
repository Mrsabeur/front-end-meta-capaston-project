const Menu = () => {
  return (
    <>
      <p>Menu</p>
    </>
  );
};

export default Menu;
